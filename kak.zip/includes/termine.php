<div class="termine-wrapper shadow-1">
    <div class="row">
        <div class="col info">
            <h3>News & Aktuelles</h3>
            <p>...  rund um die Klinik am Klausenpass</p>
        </div>
    
        <div class="col">
            <h4>Eröffnungsfeier</h4>
        </div>

        <div class="col">
            <h4>Fünf Sterne für die Klinik am Klausenpass</h4>
            <p>Die <i>KAK</i> wurde erneut als eine der besten Kliniken für Aufbaukuren schweizweit ausgezeichnet.</p>
        </div>

        <div class="col">
            <h4>Test</h4>
        </div>

    </div>

</div>